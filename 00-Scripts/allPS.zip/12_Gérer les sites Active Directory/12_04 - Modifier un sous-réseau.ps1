
Set-ADReplicationSubnet -Identity "192.168.10.0/24" -Site "Default-First-Site-Name"