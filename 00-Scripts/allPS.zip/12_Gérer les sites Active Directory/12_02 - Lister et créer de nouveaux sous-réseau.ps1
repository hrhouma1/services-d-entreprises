
Get-ADReplicationSubnet -Filter *


New-ADReplicationSubnet -Name "192.168.10.0/24" -Site "Paris" 


Get-ADReplicationSubnet -Filter *


