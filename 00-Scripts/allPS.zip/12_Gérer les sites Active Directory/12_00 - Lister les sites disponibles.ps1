
Get-ADReplicationSite


Get-ADReplicationSite -Properties *


Get-ADReplicationSite -Filter "Name -eq 'Default-First-Site-Name'"

