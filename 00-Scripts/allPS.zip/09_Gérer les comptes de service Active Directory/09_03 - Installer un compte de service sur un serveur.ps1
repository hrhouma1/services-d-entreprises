
Test-ADServiceAccount -Identity svc-test


Install-ADServiceAccount -Identity svc-test



