
Remove-ADServiceAccount -Identity svc-test -Confirm:$false