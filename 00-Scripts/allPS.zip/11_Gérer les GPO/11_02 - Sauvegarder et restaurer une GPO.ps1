
Backup-Gpo -Name TestGPO -Path C:\sauvegarde


Restore-GPO -Name TestGPO -Path C:\sauvegarde
