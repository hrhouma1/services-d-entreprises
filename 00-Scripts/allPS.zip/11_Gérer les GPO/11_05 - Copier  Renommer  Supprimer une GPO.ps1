
Copy-GPO -SourceName test -TargetName testcopie


Copy-GPO -SourceName test -TargetName testcopie1 -CopyAcl


Rename-GPO -Name test -TargetName testrenommage


Remove-GPO -Name testgpo1